#ifndef ENTRYPOINT_H
#define ENTRYPOINT_H

#include <QObject>
#include <QThread>
#include "master.h"

class EntryPoint : public QObject
{
    Q_OBJECT

public:
    explicit EntryPoint(QObject *parent = nullptr);
    ~EntryPoint();
    QThread *thread;
    void process(int countThreads, const char *file, int outputEncoder, bool useProxy);

private:
    Master *master;
    int threadCount;
    SourceData *sd;
    bool init(int countThreads, const char *sourceFilePath, int outputEncoder);

signals:
    void initMaster(int, SourceData *, bool);
    void stopWork();

public slots:
};

#endif // ENTRYPOINT_H
