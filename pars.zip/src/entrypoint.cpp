#include "entrypoint.h"
#include <iostream>

using namespace std;

/**
 * @brief EntryPoint::EntryPoint
 * @param parent
 */
EntryPoint::EntryPoint(QObject *parent) : QObject(parent)
{
    this->sd = new SourceData;
}

/**
 * @brief EntryPoint::~EntryPoint
 */
EntryPoint::~EntryPoint()
{
}

/**
 * @brief EntryPoint::process
 * @param countThreads
 * @param file
 */
void EntryPoint::process(int countThreads, const char *file, int outputEncoder, bool useProxy)
{
    this->init(countThreads, file, outputEncoder);

    this->master = new Master();
    this->thread = new QThread();

    QObject::connect(this, &EntryPoint::initMaster, this->master, &Master::initMaster);
    QObject::connect(this, &EntryPoint::stopWork, this->master, &Master::stopWork);

    this->master->moveToThread(this->thread);
    this->thread->start();
    emit initMaster(this->threadCount, this->sd, useProxy);
}

/**
  Инициализация проекта
 * @brief EntryPoint::init
 * @param threads
 * @param file
 * @param outputEncoder
 * @return
 */
bool EntryPoint::init(int countThreads, const char *sourceFilePath, int outputEncoder)
{
    this->threadCount        = countThreads;   // кол-во потоков
    this->sd->sourceFilePath = sourceFilePath; // файл с исходными данными
    this->sd->outputEncoder  = outputEncoder;  // кодировка сохранения данных

    QFile file(this->sd->sourceFilePath);
    QStringList doubleItems;
    if ((file.exists()) && (file.open(QIODevice::ReadOnly))) {
        Domain *domain = new Domain;
        domain->domain = "https://www.vseinstrumenti.ru/";
        while (!file.atEnd()) {
            QString srcLine = file.readLine().trimmed();
            srcLine.remove(QChar('\n'));
            if (srcLine.isEmpty()) continue;
            QStringList parts = srcLine.split(";");
            if (parts.length() != 3) continue;
            RString product = parts.at(2).trimmed();
            if (product.contains("Артикул поставщика")) continue;
            if (product.isEmpty()) continue;
            // product может содержать комбинацию: артикул#https://...
            RString articleValue;
            RString directUrl;
            if (product.contains("https://") || product.contains("http://")) {
                if (!product.contains("#")) {
                    printf("Вы добавили URL но не добавили знак #. Смотреть: %s", product.toLocal8Bit().data());
                    exit(1);
                }
                articleValue = product.erase_to("#");
                directUrl = product;
                directUrl.erase_data(1);
            } else {
                articleValue = product;
                directUrl.clear();
            }
            articleValue = articleValue.trimmed().toLower();
            if (doubleItems.contains(articleValue)) continue;
            doubleItems.append(articleValue);
            Article* article = new Article();
            article->article = articleValue;
            article->productUrl = directUrl;
            article->srcLine = srcLine;
            article->srcTitle = parts.at(1).trimmed();
            domain->articles.append(article);
        };
        file.close();
        this->sd->domainList.append(domain);
    } else {
        printf("I cannot open file: %s", this->sd->sourceFilePath.toUtf8().data());
        exit(1);
    }

    return true;
}
