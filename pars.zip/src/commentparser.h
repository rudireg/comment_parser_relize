#ifndef COMMENTPARSER_H
#define COMMENTPARSER_H

#include <QObject>
#include <QList>
#include "rhttp.h"
#include "rstring.h"

enum parserStatus{
    PARSE_OK,
    PARSE_ERROR,
    PARSE_BADREQUEST,
    PARSE_WARNING
};

enum workerStatus{
    wsNOTHING,
    wsSUCCESS,
    wsERROR,
    wsBADREQUEST,
    wsWARNING
};

enum wokerTask{
    wtNOTHING,
    wtPARSER
};

/**
  Структура хранит продукты, которые подлежат проверке при поиске
 * @brief The ProductItem struct
 */
struct ProductItem {
    QString title;
    QString url;
    void clear() {
        this->title.clear();
        this->url.clear();
    }
};

/**
  Структура хранит
 * @brief The CompareItem struct
 */
struct CompareItem {
    ProductItem item;
    int percent;
    void clear() {
        this->item.clear();
        this->percent = 0;
    }
};

/**
 * Структура хранит данные комментария
 * @brief The Comment struct
 */
struct Comment {
    QString name;         // имя комментатора
    QString date;         // дата
    int score;            // баллы
    QString advantage;    // достоинства
    QString disadvantage; // недостатки
    QString comment;      // комментарий
    void clear() {
        this->name.clear();
        this->date.clear();
        this->score =0;
        this->advantage.clear();
        this->disadvantage.clear();
        this->comment.clear();
    }
};

/**
 * Структура хранит данные об артикуле и его комментраиях
 * @brief The Article struct
 */
struct Article {
    QString article;           // артикул
    QString srcLine;           // исходная строка из файла
    QString srcTitle;          // исходный title продукта (из *.csv файла)
    QString productUrl;        // url по которому произошел парсинг комментариев артикуля
    QString productTitle;      // Название на сайте https://www.vseinstrumenti.ru
    QString status;            // статус
    QList <Comment*> comments; // комментарии
    void clear() {
        this->article.clear();
        this->srcLine.clear();
        this->srcTitle.clear();
        this->productUrl.clear();
        this->productTitle.clear();
        this->status.clear();
        Comment* tmp;
        while (!this->comments.isEmpty()) {
            tmp = this->comments.first();
            tmp->clear();
            delete tmp;
            this->comments.removeFirst();
        };
    }
};

/**
 * Входит в состав структуры SourceData
 * Хранит домен и его артикулы для прасинга
 * @brief The Domain struct
 */
struct Domain {
    QString domain;
    QList <Article*> articles;
    void clear() {
        this->domain.clear();
        Article* tmp;
        while (!this->articles.isEmpty()) {
            tmp = this->articles.first();
            tmp->clear();
            delete tmp;
            this->articles.removeFirst();
        };
    }
};

/**
 * Структура хранит входящие данные
 * @brief The SourceData struct
 */
struct SourceData {
    QString sourceFilePath; // путь к входному файлу
    QList <Domain*> domainList;
    int outputEncoder;
    void clear() {
        this->sourceFilePath.clear();
        Domain *tmp;
        while(!this->domainList.isEmpty()) {
            tmp = this->domainList.first();
            tmp->clear();
            delete tmp;
            this->domainList.removeFirst();
        };
        this->outputEncoder =0;
    }
};

/**
 * Структура хранит данные для рабочего потока
 * @brief The TInfo struct
 */
struct TInfo {
    int     status;
    int     task;
    int     lastError;
    QString errorText;
    Article *article;
    void clear() {
        this->status = wsNOTHING;
        this->task   = wtNOTHING;
        this->lastError =0;
        this->errorText.clear();
        this->article = nullptr;
    }
};

/**
 * Класс парсит комментарии
 * @brief The CommentParser class
 */
class CommentParser : public QObject
{
    Q_OBJECT

public:
    explicit CommentParser(QObject *parent = nullptr);
    ~CommentParser();
    int doParser(Article *article);

signals:

public slots:
protected:
    RHttp *http;
    bool Get(const QString &url);
    bool Post(const QString &url, const QByteArray &data);
    QString httpsToHttp(QString url);
    QString httpToHttps(QString url);
    void pauseSec(int sec); 
    int initVchecks();
    int parseComments(RString inb, Article *article);
    QString parseData(RString comBlock);
    QString parseName(RString comBlock);
    int parseScore(RString comBlock);
    QString parseComment(RString comBlock);
    QString parseAdvantage(RString comBlock);
    QString parseDisadvantage(RString comBlock);
    int getProductPage(Article* article);
    int searchArticle(Article* article);
    int getDirectPage(QString url, QString &productTitle);

private:
    int searchRequest(QString text);
    QList<ProductItem> *getProductItems(RString inb);
    int compareString(QString source, QString dist);
};

#endif // COMMENTPARSER_H
