#include "worker.h"

/**
 * Конструктор
 * @brief Worker::Worker
 * @param parent
 */
Worker::Worker(QObject *parent) :
    QObject(parent)
{
    this->info = nullptr;
    this->commentParser = nullptr;
}

/**
 * Высвобождение памяти Worker
 * @brief Worker::free_thread
 */
void Worker::free_thread()
{
    if (this->info) {
        this->info->clear();
        delete this->info;
    }
   if (this->commentParser != nullptr) delete this->commentParser;
   emit iAmReadyQuit();
}

/**
 * Пробуждение потоков
 * @brief Worker::wakeUpAllWorkers
 */
void Worker::wakeUpAllWorkers()
{
    this->info->clear();
    emit iAmReady(this->info);
}

/**
 * Инициализация рабочего потока
 * @brief Worker::init_workers
 */
void Worker::init_workers()
{
    this->info = new TInfo;
    this->commentParser = new CommentParser();
}

/**
 * Выполнение задания
 * @brief Worker::do_task
 */
void Worker::do_task()
{
    switch(this->info->task)
    {
    case wtPARSER:
        switch (this->commentParser->doParser(this->info->article)) {
        case PARSE_OK:
            this->info->status = wsSUCCESS;
            break;
        case PARSE_ERROR:
            this->info->status = wsERROR;
            break;
        case PARSE_BADREQUEST:
            this->info->status = wsBADREQUEST;
            break;
        case PARSE_WARNING:
            this->info->status = wsWARNING;
            break;
        default:
            this->info->status = wsERROR;
        }
    }
    emit iAmReady(this->info);
}
