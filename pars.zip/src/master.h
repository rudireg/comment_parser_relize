#ifndef MASTER_H
#define MASTER_H

#define MAX_COUNT_THREAD 30

#include <QObject>
#include <QList>
#include <QThread>
#include <QFile>
#include <QTextStream>
#include "worker.h"

enum OutputCodec { UTF, WIN };

/**
 * Структура хранит счетчики программы
 * @brief The counters struct
 */
struct Counters {
    int articles;
    int doneArticles;
    int badRequest;
    int errors;
    int warning;
    void clear() {
        this->articles =0;
        this->doneArticles =0;
        this->badRequest =0;
        this->errors =0;
        this->warning =0;
    }
};

class Master : public QObject
{
    Q_OBJECT
public:
    explicit Master(QObject *parent = nullptr);

private:
    Counters counters;          //Счетчики
    SourceData *sd;            //Данные для парсинга
    bool doStop;               //Флаг остановки приложения
    bool useProxy;             //Использовать прокси
    int currItemIndex;         //Индекс текущего парсинга
    int countThreads;         //Кол. потоков
    QList <Worker*> *thrPool;  //Пул рабочих потоков

    void create_workers();  //Создать рабочие потоки
    void stop_and_delete_thread(Worker *W);
    void emit_task(QObject *obj);
    void emit_free_thread(QObject *obj);
    bool prepareData(SourceData *sd);
    QString removeFirstEnd(QString str);
    void saveParserData();

signals:
    void wakeUpAllWorkers();
    void init_workers();
    void runTask();
    void free_thread();

public slots:
    void initMaster(int countThreads, SourceData *sd, bool useProxy);
    void threadReadyQuit();
    void setTask(TInfo* info);
    void stopWork();

};

#endif // MASTER_H
