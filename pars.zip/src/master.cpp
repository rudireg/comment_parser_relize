#include <QCoreApplication>
#include "master.h"

/**
 * Конструктор
 * @brief Master::Master
 * @param parent
 */
Master::Master(QObject *parent) :
    QObject(parent)
{
    this->thrPool = new QList <Worker*>; // высвобождается тут: stop_and_delete_thread
}

/**
 * Инициализация Master потока
 * @brief Master::initMaster
 * @param countThreads
 * @param sd
 * @param useProxy
 */
void Master::initMaster(int countThreads, SourceData *sd, bool useProxy)
{
    printf("Start Init Master\n");
    if (countThreads < 1) this->countThreads =1;
    else if(countThreads > MAX_COUNT_THREAD) this->countThreads = MAX_COUNT_THREAD;
    else this->countThreads = countThreads;
    this->useProxy = useProxy; // нужно ли использовать прокси
    this->sd = sd; // запомнить данные для парсинга
    this->currItemIndex =0;
    this->doStop = false;
    this->counters.clear();
    this->counters.articles = this->sd->domainList.at(0)->articles.count();
    this->create_workers(); // создаем рабочие потоки
    printf("Wake up all threads\n");
    emit wakeUpAllWorkers(); // пробуждаем рабочие потоки
}

/**
 * Создаем рабочие потоки
 * @brief Master::create_workers
 */
void Master::create_workers()
{
    if (!this->thrPool->isEmpty()) this->thrPool->clear();
    Worker *worker;
    QThread *thread;
    for (int i=0; i<this->countThreads; ++i) {
        printf("Wake up thread: %d\n", i+1);
        worker = new Worker;
        thread = new QThread;
        this->thrPool->append(worker);

        connect(thread,SIGNAL(finished()),thread,SLOT(deleteLater()));
        connect(this,SIGNAL(init_workers()),worker,SLOT(init_workers()));
        connect(this,SIGNAL(wakeUpAllWorkers()),worker,SLOT(wakeUpAllWorkers()));
        connect(worker,SIGNAL(iAmReady(TInfo*)),this,SLOT(setTask(TInfo*)));
        connect(worker,SIGNAL(iAmReadyQuit()),this,SLOT(threadReadyQuit()));

        worker->setThreadID(i);
        worker->moveToThread(thread);
        thread->start();
    };
    emit init_workers(); // инициализация рабочих лошадок
}

/**
 * Назначае задачу для освободившегося потока
 * @brief Master::setTask
 * @param info
 */
void Master::setTask(TInfo* info)
{
    Worker  *W = static_cast<Worker*>(this->sender());
    QThread *T = W->thread();
    if (!W || !T) {
        printf("Critical error: W == NULL || T == NULL\n");
        exit(1);
    }
    switch (info->status) {
    case wsSUCCESS:
        this->counters.doneArticles ++;
        if (info->article->comments.count() > 0) {
            info->article->status = QString("COMMENT %1").arg(info->article->comments.count());
        } else {
            info->article->status = "NO COMMENT";
        }
        printf("#%d: SUCCESS %s Артикул: %s\n", this->counters.doneArticles, info->article->status.toUtf8().data(), info->article->article.toUtf8().data());
        break;
    case wsERROR:
        this->counters.errors ++;
        info->article->status = "ERROR";
        printf("#%d: ERROR Артикул: %s\n", this->counters.errors, info->article->article.toUtf8().data());
        break;
    case wsBADREQUEST:
        this->counters.badRequest ++;
        info->article->status = "BADREQUEST";
        printf("#%d: BADREQUEST Артикул: %s\n", this->counters.badRequest, info->article->article.toUtf8().data());
         break;
    case wsWARNING:
        this->counters.warning ++;
        info->article->status = "NOT FOUND";
        printf("#%d: NOT FOUND Артикул: %s\n", this->counters.warning, info->article->article.toUtf8().data());
        break;
    }
    //**************************************************************
    //**************** Назначаем новое задание *********************
    //**************************************************************
    info->clear();
    if (this->doStop) {
        this->stop_and_delete_thread(W);
        return;
    }
    // берем данные для парсинга
    if (this->currItemIndex < this->sd->domainList.at(0)->articles.count()) {
        info->article = this->sd->domainList.at(0)->articles.at(this->currItemIndex ++);
    } else {
        this->doStop = true;
        this->stop_and_delete_thread(W);
        return;
    }
    info->task = wtPARSER;
    this->emit_task(W);
}

/**
 * Высвобождение и удаление рабочего потока
 * @brief Master::stop_and_delete_thread
 * @param W
 */
void Master::stop_and_delete_thread(Worker *W)
{
   for (int i=0; i < this->thrPool->count(); ++i) {
       if (this->thrPool->at(i) == W) {
           printf("Останавливаем поток: %d\n", W->threadID());
           this->thrPool->removeAt(i);
           this->emit_free_thread(W);
           break;
       }
   };
   if (this->thrPool->isEmpty()) {
       printf("All threads are stoped\n");
       printf("Saving data\n");
       this->saveParserData();
       printf("Work is done\n");
   }
}

/**
 * Запуск рабочего потока
 * @brief Master::emit_task
 * @param obj
 */
void Master::emit_task(QObject *obj)
{
    if(this->doStop) return;
    connect(this,SIGNAL(runTask()),obj,SLOT(do_task()));
    emit runTask();
    disconnect(this,SIGNAL(runTask()),obj,SLOT(do_task()));
}

/**
 * Высвобождение рабочего потока
 * @brief Master::emit_free_thread
 * @param obj
 */
void Master::emit_free_thread(QObject *obj)
{
    connect(this,SIGNAL(free_thread()),obj,SLOT(free_thread()));
    emit free_thread();
    disconnect(this,SIGNAL(free_thread()),obj,SLOT(free_thread()));
}

/**
 * Поток освобожден и готов к завершению
 * @brief Master::threadReadyQuit
 */
void Master::threadReadyQuit()
{
    Worker  *W = static_cast<Worker*>(this->sender());
    QThread *T = W->thread();
    W->deleteLater();
    T->quit();
}

/**
  Остановка работы парсинга
 * @brief Master::stopWork
 */
void Master::stopWork()
{
    this->doStop = true;
}

/**
 * Сохранить данные
 * @brief Master::saveParserData
 */
void Master::saveParserData()
{
    QString val;
    QStringList parts = this->sd->sourceFilePath.split('/');
    QString path = QCoreApplication::applicationDirPath();
    QString comment_file = QString("%1/data/comments_%2").arg(path).arg(parts.at(parts.length()-1));
    QFile filename(comment_file);
    QString log_file = QString("%1/data/log_%2").arg(path).arg(parts.at(parts.length()-1));
    QFile logFile(log_file);
    if (!filename.open(QIODevice::WriteOnly | QIODevice::Text)) {
        printf("I cant save to %s", comment_file.toUtf8().data());
        exit(1);
    }
    if (!logFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
        filename.close();
        printf("I cant save to %s", log_file.toUtf8().data());
        exit(1);
    }
    QTextStream out(&filename);
    QTextStream log(&logFile);
    // устанавливаем кодировку выходных данных
    if (this->sd->outputEncoder == OutputCodec::UTF) {
        out.setCodec(QTextCodec::codecForName("UTF-8"));
        log.setCodec(QTextCodec::codecForName("UTF-8"));
    } else {
        out.setCodec(QTextCodec::codecForName("Windows-1251"));
        log.setCodec(QTextCodec::codecForName("Windows-1251"));
    }
    // out
    out << QString("Name;Article;Name;Date;Score;Advantage;Disadvantage;Comment\n");
    foreach (Article* article, this->sd->domainList.at(0)->articles) {
        log << QString("%1;%2;%3;%4\n").arg(article->srcLine).arg(article->status).arg(article->productUrl).arg(article->productTitle.replace(QChar(';'), ""));
        foreach (Comment* comment, article->comments) {
            out << QString("%1;%2;%3;%4;%5;%6;%7;%8\n")
                   .arg(article->productTitle.replace(QChar(';'), ""))
                   .arg(article->article)
                   .arg(comment->name)
                   .arg(comment->date)
                   .arg(comment->score)
                   .arg(comment->advantage)
                   .arg(comment->disadvantage)
                   .arg(comment->comment);
        };
    };
    filename.close();
    logFile.close();
}
//-------------------------------------------------------
