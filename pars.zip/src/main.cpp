#include <QCoreApplication>
#include <QTextCodec>
#include <QDir>
#include <stdio.h>
#include "master.h"
#include "entrypoint.h"

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    QTextCodec *codecUtf8 = QTextCodec::codecForName("utf8"); //Windows-1251
    QTextCodec::setCodecForLocale(codecUtf8);

    qRegisterMetaType<TInfo>("TInfo");
    qRegisterMetaType<SourceData>("SourceData");
    qRegisterMetaType<Counters>("Counters");

    if (argc != 4) {
        printf("You should pass 2 arguments: (int) threadCount (string) sourceFile (string) outputEncoder (utf|win)\n");
        exit(0);
     }

    int threadCount = 0;
    sscanf(argv[1], "%d", &threadCount);

    char *file =  argv[2];
    int outputEncoder = (strcmp(argv[3], "utf") == 0)? OutputCodec::UTF : OutputCodec::WIN; // кодировка для выходного файла

    if (threadCount < 1 || strlen(file) < 1) {
        printf("You should pass 2 arguments: (int) threadCount (string) sourceFile (string) outputEncoder (utf|win)\n");
        exit(0);
    }

    // start
    (new EntryPoint())->process(threadCount, file, outputEncoder, false);

    return a.exec();
}
