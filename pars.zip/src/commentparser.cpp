﻿#include "commentparser.h"

/**
 * @brief CommentParser::CommentParser
 * @param parent
 */
CommentParser::CommentParser(QObject *parent) : QObject(parent)
{
    this->http = new RHttp(this);
    this->http->setTimeOut(30000);
}

/**
 * @brief CommentParser::~CommentParser
 */
CommentParser::~CommentParser()
{
    this->http->deleteLater();
}

/**
 * @brief CommentParser::Get
 * @param url
 * @return
 */
bool CommentParser::Get(const QString &url)
{
    int step =0, limit =3;
    bool rez;
    do{
        rez = this->http->get(url);
        step ++;
        if(step > 1) this->pauseSec(5);
        if(step >= limit) break;
    }while(!rez);
    return rez;
}

/**
 * @brief CommentParser::Post
 * @param url
 * @param data
 * @return
 */
bool CommentParser::Post(const QString &url, const QByteArray &data)
{
    int step =0, limit =3;
    bool rez;
    do{
        rez = this->http->post(url, data);
        step ++;
        if(step > 1) this->pauseSec(5);
        if(step >= limit) break;
    }while(!rez);
    return rez;
}

/**
  Пауза
 * @brief partParser::pauseSec
 * @param sec
 */
void CommentParser::pauseSec(int sec)
{
    QEventLoop EL;
    QTimer timer;
    timer.singleShot((sec * 1000),&EL,SLOT(quit()));
    EL.exec();
}

/**
 * Замена https:// на http://
 * @brief partParser::httpsToHttp
 * @param url
 * @return
 */
QString CommentParser::httpsToHttp(QString url)
{
    if (url.contains("https://")) {
        url.replace(0, 5, "http");
    }
    return url;
}

/**
 * Замена http:// на https://
 * @brief partParser::httpToHttps
 * @param url
 * @return
 */
QString CommentParser::httpToHttps(QString url)
{
    if (url.contains("http://")) {
        url.replace(0, 4, "https");
    }
    return url;
}

/**
 * Парсим комментарий и его характеристики
 * @brief CommentParser::doParser
 * @param domain
 * @return
 */
int CommentParser::doParser(Article *article)
{
    int res;
    if (!(res = this->getProductPage(article))) {
        return res;
    }
    RString inb = this->http->inbuffQString();
    // inb.saveToFile("inb.html");
    if (!inb.contains(">Код товара:<")) {
        if (!inb.contains(">Результаты поиска<") && !inb.contains(">Все товары<")) {
            return PARSE_ERROR;
        }
        return PARSE_WARNING;
    }
    this->parseComments(inb, article);
    return PARSE_OK;
}

/**
 * Прасим комментарии артикуля
 * @brief CommentParser::parseComments
 * @param inb
 * @param article
 * @return
 */
int CommentParser::parseComments(RString inb, Article* article)
{
    QString startBlock = "<div id=\"tabResponses_content\"";
    QString endBlock = ">Количество отзывов: <";
    QString startComment = "response-item";
    QString endComment = "</li>";
    RString block = inb.cut_str_to_str(startBlock, endBlock);
    if (!block.isEmpty()) {
        RString comBlock;
        while (block.contains(startComment)) {
            comBlock = block.cut_str_to_str(startComment, endComment);
            Comment* comment      = new Comment();
            comment->date         = this->parseData(comBlock);         // parse date
            comment->name         = this->parseName(comBlock);         // parse name
            comment->score        = this->parseScore(comBlock);        // parse score
            comment->comment      = this->parseComment(comBlock);      // parse comment
            comment->advantage    = this->parseAdvantage(comBlock);    // parse advantage
            comment->disadvantage = this->parseDisadvantage(comBlock); // parse disadvantage
            article->comments.append(comment);
            block.erase_to(startComment);
            block.erase_data(1);
        };
    }
    return PARSE_OK;
}

/**
 * Спарсить дату
 * @brief CommentParser::parseData
 * @param comBlock
 * @return
 */
QString CommentParser::parseData(RString comBlock)
{
    RString block = comBlock.cut_str_to_str("response-data", "<");
    if (!block.isEmpty()) {
        block.erase_to(">");
        block.erase_data(1);
        block.replace(QRegExp("[^0-9-]"), "");
        return QString(block);
    }
    return "";
}

/**
 * Спарсить имя
 * @brief CommentParser::parseName
 * @param comBlock
 * @return
 */
QString CommentParser::parseName(RString comBlock)
{
    RString block = comBlock.cut_str_to_str("response-author", "<");
    if (!block.isEmpty()) {
        block.erase_to(">");
        block.erase_data(1);
        block.replace("&quot;", "\"");
        block.replace(";", ".");
        block.replace("\"", " ");
        return QString(block);
    }
    return "";
}

/**
 * Спарсить очки голосования
 * @brief CommentParser::parseScore
 * @param comBlock
 * @return
 */
int CommentParser::parseScore(RString comBlock)
{
    RString block = comBlock.cut_str_to_str("ratingValue", ">");
    if (!block.isEmpty()) {
        QString score = block.cut_str_to_str("content=\"", "\"");
        return score.toInt();
    }
    return 0;
}

/**
 * Спарсить текстовое предтсавление комментария покупателя
 * @brief CommentParser::parseComment
 * @param comBlock
 * @return
 */
QString CommentParser::parseComment(RString comBlock)
{
    RString tmp = comBlock;
    QString met = "response-content-block";
    RString block;
    while (tmp.contains(met)) {
        tmp.erase_to(met);
        block = tmp.cut_to_str("</div>");
        if (!block.contains(">Комментарий:<")) {
            tmp.erase_data(1);
            continue;
        }
        block = block.cut_str_to_str("response-content-text", "</span>");
        if (!block.isEmpty()) {
            block.erase_to(">");
            block.erase_data(1);
            block.replace("<br />", "");
            block.replace("\r", "");
            block.replace("\n", "");
            block.replace("&quot;", "\"");
            block.replace("\"", " ");
            block.replace(";", ".");
            return QString(block);
        }
    };
    return "";
}

/**
 * Спарсить достоинства товара
 * @brief CommentParser::parseComment
 * @param comBlock
 * @return
 */
QString CommentParser::parseAdvantage(RString comBlock)
{
    RString tmp = comBlock;
    QString met = "response-content-block";
    RString block;
    while (tmp.contains(met)) {
        tmp.erase_to(met);
        block = tmp.cut_to_str("</div>");
        if (!block.contains(">Достоинства:<")) {
            tmp.erase_data(1);
            continue;
        }
        block = block.cut_str_to_str("response-content-text", "</span>");
        if (!block.isEmpty()) {
            block.erase_to(">");
            block.erase_data(1);
            block.replace("<br />", "");
            block.replace("\r", "");
            block.replace("\n", "");
            block.replace("&quot;", "\"");
            block.replace("\"", " ");
            block.replace(";", ".");
            return QString(block);
        }
    };
    return "";
}

/**
* Спарсить недостатки товара
* @brief CommentParser::parseComment
* @param comBlock
* @return
*/
QString CommentParser::parseDisadvantage(RString comBlock)
{
   RString tmp = comBlock;
   QString met = "response-content-block";
   RString block;
   while (tmp.contains(met)) {
       tmp.erase_to(met);
       block = tmp.cut_to_str("</div>");
       if (!block.contains(">Недостатки:<")) {
           tmp.erase_data(1);
           continue;
       }
       block = block.cut_str_to_str("response-content-text", "</span>");
       if (!block.isEmpty()) {
           block.erase_to(">");
           block.erase_data(1);
           block.replace("<br />", "");
           block.replace("\r", "");
           block.replace("\n", "");
           block.replace("&quot;", "\"");
           block.replace("\"", " ");
           block.replace(";", ".");
           return QString(block);
       }
   };
   return "";
}

/**
 * Получить страницу с товаром
 * @brief CommentParser::getProductPage
 * @param article
 * @param targetProductUrl
 * @param productTitle
 * @return
 */
int CommentParser::getProductPage(Article* article)
{
    // если поиск по конкретному url
    if (!article->productUrl.isEmpty() && (article->productUrl.startsWith("http://") || article->productUrl.startsWith("https://"))) {
        return this->getDirectPage(article->productUrl, article->productTitle);
    } else {
        return this->searchArticle(article);
    }
}

/**
 * Переход по прямой ссылке
 * @brief CommentParser::getDirectPage
 * @param url
 * @param targetProductUrl
 * @param productTitle
 * @return
 */
int CommentParser::getDirectPage(QString url, QString &productTitle)
{
    this->http->setUserAgent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36");
    this->http->setReferer("https://www.vseinstrumenti.ru/");
    this->http->setAutoRedirect(false);
    int res = this->Get(url);
    productTitle = "Прямой заход по ссылке";
    while (this->http->httpStatusCode() == 307 || this->http->httpStatusCode() == 302) {
        if (this->http->httpStatusCode() == 307) {
            res = this->initVchecks();
        }
        if (this->http->httpStatusCode() == 302) {
           res = this->Get(this->http->Location302());
           if (this->http->httpStatusCode() == 307) {
               res = this->initVchecks();
           }
        }
    };
    return res;
}

/**
   Для поиска имеем два занчения: артикул (article) и название товара (source_title).
   Механизм поиска следующий: делаем поиск по названию товара, если результат отрицательный, то делаем поиск по артикулу.
   В случае успеха пробуем парсить комментарии.

   Более подробное описание шагов поиска:
   1. Делаем поиск по названию продукта (source_title)
       1.1 В результате поиска получаем список товаров, каждый товар имеет свое название (product_title)
       1.2 Каждый product_title сверяем с source_title
           1.2.1 Если свопадения слов в названиях товаров >= 70% - считаем что продукт найден
   2. Если поиск по пункту 1 отрицатален, делаем поиск по артикулу (article) а в памяти храним соответсвующий source_title
       2.1 В результате поиска получаем список товаров, каждый товар имеет свое название (product_title)
       2.2 Каждый product_title сверяем с source_title
           2.2.1 Если свопадения слов в названиях товаров >= 70% - считаем что продукт найден
   3. В случае успешного поиска пытаемся парсить комментарии

 * @brief CommentParser::searchArticle
 * @param article
 * @return
 */
int CommentParser::searchArticle(Article* article)
{
    RString inb;
    int res = PARSE_ERROR;
    QList<ProductItem>* productItems = nullptr;
    QList<CompareItem>* compareItemsTitle = new QList<CompareItem>;
    QList<CompareItem>* compareItemsArticle = new QList<CompareItem>;

    // поиск по title
    if (!article->srcTitle.isEmpty()) {
        if ((res = this->searchRequest(article->srcTitle))) {
            inb = this->http->inbuffQString();
            productItems = this->getProductItems(inb);
            foreach(ProductItem item, *productItems) {
                CompareItem compareItem;
                compareItem.item.url   = item.url;
                compareItem.item.title = item.title;
                compareItem.percent = this->compareString(article->srcTitle, item.title);
                compareItemsTitle->append(compareItem);
            }
            delete productItems;
        }
    }

    // поиск по article
    if (!article->article.isEmpty()) {
        if ((res = this->searchRequest(article->article))) {
            inb = this->http->inbuffQString();
            productItems = this->getProductItems(inb);
            foreach(ProductItem item, *productItems) {
                CompareItem compareItem;
                compareItem.item.url   = item.url;
                compareItem.item.title = item.title;
                compareItem.percent = this->compareString(article->srcTitle, item.title);
                compareItemsArticle->append(compareItem);
            }
            delete productItems;
        }
    }

    int maxTitlePercent = 0;
    int maxArticlePercent = 0;
    // Ищем какой какой процент имеет наивысший балл совпадения серди title
    foreach (CompareItem item, *compareItemsTitle) {
        if (item.percent > maxTitlePercent) {
            maxTitlePercent = item.percent;
        }
    }

    // Ищем какой какой процент имеет наивысший балл совпадения серди aerticle
    foreach (CompareItem item, *compareItemsArticle) {
        if (item.percent > maxArticlePercent) {
            maxArticlePercent = item.percent;
        }
    }

    // Если обе проверки провалились
    if (maxTitlePercent < 50 && maxArticlePercent < 50) {
        return res;
    }
    // Определяем наивысшее совпадение среди полученных процентов совпадения
    if (maxTitlePercent > maxArticlePercent || maxTitlePercent == maxArticlePercent) {
        foreach (CompareItem curr, *compareItemsTitle) {
            if (curr.percent == maxTitlePercent) {
                article->productUrl   = curr.item.url;
                article->productTitle = curr.item.title;
            }
            break;
        }
    } else if (maxArticlePercent > maxTitlePercent) {
        foreach (CompareItem curr, *compareItemsArticle) {
            if (curr.percent == maxArticlePercent) {
                article->productUrl   = curr.item.url;
                article->productTitle = curr.item.title;
            }
            break;
        }
    }

    delete compareItemsTitle;
    delete compareItemsArticle;

    res = this->Get(article->productUrl);
    if (res) {
        if (this->http->httpStatusCode() == 307) {
            res = this->initVchecks();
        }
        if (this->http->httpStatusCode() == 302) {
           res = this->Get(this->http->Location302());
           if (this->http->httpStatusCode() == 307) {
               res = this->initVchecks();
           }
        }
    }
    return res;
}

/**
  Сравнение двух строк по словам. Возвращает размер совпадения в проыентах
  Пример, если есть 2 строки
  1) hello world sun
  2) kiss sun world moon hello
  Все слова из строки 1 присутсвуют в строке 2, поэтому результат совпадения равен 100%
 * @brief CommentParser::compareString
 * @param source
 * @param dist
 * @param percent
 * @return
 */
int CommentParser::compareString(QString source, QString dist)
{
    QStringList first, second;
    source.replace(QRegExp("[^\\d\\w]"), " ");
    source.replace(QRegExp("\\s+"), " ");
    dist.replace(QRegExp("[^\\d\\w]"), " ");
    dist.replace(QRegExp("\\s+"), " ");
    source = source.trimmed().toLower();
    dist   = dist.trimmed().toLower();
    if (source.isEmpty() || dist.isEmpty()) return false;
    // разбиваем на массивы
    first  = source.split(" ");
    second = dist.split(" ");

    // удаляем если длина слова равна 1 символу
    QStringList::iterator it = first.begin();
    while (it != first.end()) {
        if ((*it).length() == 1) {
            it = first.erase(it);
        } else {
            ++it;
        }
    }
    // удаляем если длина слова равна 1 символу
    it = second.begin();
    while (it != second.end()) {
        if ((*it).length() == 1) {
            it = second.erase(it);
        } else {
            ++it;
        }
    }

    // сравниваем слова в двух массивах что бы определить процент совпадения (percent)
    QStringList tmp = second;
    it = first.begin();
    int find = 0;
    while (it != first.end()) {
        if (tmp.contains(*it)) {
            find ++;
            tmp.removeOne(*it);
        }
        ++it;
    }
    int diff = 100 / first.count() * find;
    return diff;
}

/**
  Получить список продуктов, отданых поиском
 * @brief CommentParser::getProductItems
 * @param inb
 * @return
 */
QList<ProductItem>* CommentParser::getProductItems(RString inb)
{
    RString block, tmp;
    QString productName = "<div class=\"product-name";
    QList<ProductItem>* productItems = new QList<ProductItem>;
    if (inb.contains(">Результаты поиска<") || inb.contains(">Все товары<")) {
        while (inb.contains(productName)) {
            ProductItem item;
            inb.erase_to(productName);
            block = inb.cut_str_to_str(productName, "</div>");
            tmp = block.cut_str_to_str("title=", ">").toLower();
            item.title = tmp.cut_str_to_str("\"", "\"");
            tmp = block.cut_str_to_str("href=\"", "\"");
            if (tmp.startsWith("http")) {
                item.url = tmp;
            } else {
                 item.url = QString("https://www.vseinstrumenti.ru%1").arg(tmp);
            }
            inb.erase_data(1);
            if (!item.title.isEmpty() && !item.url.isEmpty()) {
                productItems->append(item);
            }
        };
    }
    return productItems;
}

int CommentParser::searchRequest(QString text)
{
    QString url = QString("https://www.vseinstrumenti.ru/search_main.php?what=%1").arg(text.trimmed().replace(QChar(' '), "+"));
    this->http->setUserAgent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36");
    this->http->setReferer("https://www.vseinstrumenti.ru/");
    this->http->setAutoRedirect(false);
    int res = this->Get(url);
    if (res) {
        if (this->http->httpStatusCode() == 307) {
            res = this->initVchecks();
        }
        if (this->http->httpStatusCode() == 302) {
           res = this->Get(this->http->Location302());
           if (this->http->httpStatusCode() == 307) {
               res = this->initVchecks();
           }
        }
    }
    return res;
}

/**
 * Проходим проверку
 * @brief CommentParser::initVchecks
 * @return
 */
int CommentParser::initVchecks()
{
    QString url = this->http->Location302();
    int res = this->Get(url);
    if (res) {
        RString inb = this->http->inbuffQString();
        // inb.saveToFile("ERROR/check.html");
        RString tmp, name, value;
        QList<QNetworkCookie> cookies = this->http->getAllCookies();
        while (inb.contains("document.cookie=")) {
             inb.erase_to("document.cookie=");
             inb.erase_data(1);
             tmp = inb.cut_str_to_str(".cookie=\"", ";");
             name = tmp.erase_to("=");
             tmp.erase_data(1);
             value = tmp;
             QNetworkCookie cookie;
             cookie.setName(name.toUtf8());
             cookie.setValue(value.toUtf8());
             cookie.setPath("/");
             cookies.append(cookie);
        };
        this->http->setAllCookies(cookies);
        RString newUrl = inb.cut_str_to_str("makeUrl(\"", "\"");
        RString paramBlock = inb.cut_str_to_str("url += \"", ";");
        newUrl += paramBlock.cut_to_str("\"");
        while (paramBlock.contains("+ \"&\" +")) {
            newUrl += "&";
            newUrl += paramBlock.cut_str_to_str("\"&\" + \"", "\"");
            paramBlock.erase_to("+ \"&\"");
            paramBlock.erase_data(3);
        };
        // newUrl.saveToFile("ERROR/newURL.txt");
        res = this->Get(newUrl);
    }
    return res;
}


